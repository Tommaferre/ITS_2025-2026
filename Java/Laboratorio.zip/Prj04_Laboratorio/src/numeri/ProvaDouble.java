package numeri;

public class ProvaDouble {
	public static void main(String[] args) {
		
		float  f = 4.5;
		double  d = 4.5; //preferibilmente usare double
		
	}

}
