# The group

## Author

Tommaso Ferrero SWD

## Test of the exercise

The group  
● Use the previous function to write another function called group that checks whether a string is part of another longer string that is a list of names of a group  
The function should output the results to the console  

## Description of the solution of the exercise

This exercise use the function of the previous exercise 10-contains and have another function called group that checks whether a string is part of another longer string that is a list of names of a group.
