# Money

## Author

Tommaso Ferrero SWD

## Requests

Money  
● Create a function called money  
● It should take a single parameter, an amount, and return 'amount dollars'  
● Add a smiley at the end if the amount is 1 million. Deal with edge cases  
For example  
money(1): 1 dollar  
money(10): 10 dollars  
money(1000000): 1000000 dollars ;)  

## Description of the solution of the exercise

This exercise has a function called money that takes a single parameter, an amount, and return that amount with dollar or dollars depending if the amount it's 1 or more.  
If the amount is 1 million add also a smiley.  
