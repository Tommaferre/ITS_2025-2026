# Cut Me Up

## Author

Tommaso Ferrero SWD

## Test of the exercise

In the exercise folder create a .txt or .doc or .md file in which you explain the difference between the following string methods

- slice()  
- substring()  
- substr()

Explain the differences in terms of parameters and behavior
Provide code examples to prove your point  

## Description of the solution of the exercise

I've writed a comparison of JavaScript's string extraction methods and their key differences. In the end of the exercise i put some advices for my future usage of them to remember which one i should use based on what i have to do.  
