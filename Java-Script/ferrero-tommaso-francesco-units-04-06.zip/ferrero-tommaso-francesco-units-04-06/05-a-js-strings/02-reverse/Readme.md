# Reverse

## Author

Tommaso Ferrero SWD

## Request

Reverse  
● Write a JavaScript function called reverse which has one parameter, a string, and which returns that string in reverse  
● For example, the call reverse("foobar") should return the string "raboof"

## Description of the solution for the exercise

This is practically the same script of the exercise 01-print-reverse, the difference is about that the function doesn't print directly the value of the string reversed but it only reverse the string and return that value that is printed outside the function.
