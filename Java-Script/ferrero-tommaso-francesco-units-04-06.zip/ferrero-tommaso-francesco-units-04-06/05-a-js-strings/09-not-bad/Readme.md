# Not Bad

## Author

Tommaso Ferrero SWD

## Test of the exercise

Not Bad  
● Create a function called notBad that takes a single parameter, a string  
● It should find the first appearance of the substring 'not' and 'bad'  
● If the 'bad' follows the 'not', then it should replace the whole 'not'...'bad' substring with 'good' and return the result  
● If it doesn't find 'not' and 'bad' in the right sequence (or at all), just return the original sentence  

## Description of the solution of the exercise

This exercise have a function called notBad that takes a string, search if in the string there are "not" and "bad", if it find them in this order change the words beetween "not" and "bad" (included) with good and return the result.  
If it doesn't find "not" and "bad" in the right sequence (or at all) just return the original sentence.
