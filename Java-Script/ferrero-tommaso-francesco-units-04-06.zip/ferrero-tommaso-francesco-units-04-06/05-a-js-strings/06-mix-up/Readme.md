# MixUp

## Author

Tommaso Ferrero SWD

## Requests

MixUp  
● Create a function called mixUp  
● It should take in two strings, and return the concatenation of the two strings (separated by a space) slicing out and swapping the first 2 characters of each  
● You can assume that the strings are at least 2 characters long  
For example  
mixUp('mix', 'pod'): 'pox mid'  
mixUp('dog', 'dinner'): 'dig donner'  

## Description of the solution of the exercise

This exercise have a function that takes two  strings and return the concatenation of the two strings sliced out with the first 2 characters of each swapped.
This could be useful for creating playful word variations or simple string manipulations.
