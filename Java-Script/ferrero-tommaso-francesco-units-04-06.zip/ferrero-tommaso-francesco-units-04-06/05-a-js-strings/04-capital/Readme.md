# Capital

## Author

Tommaso Ferrero SWD

## Request

Capital  
● Write a JavaScript function called capital which has one parameter, a string, and which returns that string with the first letter capitalized  
● For example, the call capital("hello world") should return the string "Hello world"  

## Description of the solution of the exercise

This exercise is about writing a JavaScript function called capital which has one parameter, a string, and which returns that string with the first letter capitalized using the string method toUppercase().
