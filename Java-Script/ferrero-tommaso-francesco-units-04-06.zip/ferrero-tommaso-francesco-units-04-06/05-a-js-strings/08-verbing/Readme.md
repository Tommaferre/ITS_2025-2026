# Verbing

## Author

Tommaso Ferrero SWD

## Test of the exercise

Verbing  
● Create a function called verbing  
● It should take a single parameter, a string. If its length is at least 3, it should add 'ing' to its end, unless it already ends in 'ing', in which case it should add 'ly' instead  
● If the string length is less than 3, it should leave it unchanged

## Description of the solution of the exercise

In this exercise, the verbing function adds "ing" to the end of a string if its length is at least 3, unless it already ends with "ing", in which case it adds "ly" instead. If the string length is less than 3, it remains unchanged.
