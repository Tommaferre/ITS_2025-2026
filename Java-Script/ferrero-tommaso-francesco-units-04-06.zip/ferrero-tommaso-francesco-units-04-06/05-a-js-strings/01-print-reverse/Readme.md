# Print reverse

## Author

Tommaso Ferrero SWD

## Request

Print reverse  
● Write a JavaScript function called printReverse which has one parameter, a string, and which prints that string in reverse  
● For example, the call printReverse("foobar") should result in "raboof" being displayed

## Description of the solution for the exercise

This exercise is about writing a JavaScript function that has one parameter, a string, and which prints that string in reverse.
There are also two examples for the usage.
