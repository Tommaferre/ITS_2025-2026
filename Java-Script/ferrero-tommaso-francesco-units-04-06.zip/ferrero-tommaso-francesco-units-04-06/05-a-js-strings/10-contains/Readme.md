# Contains

## Author

Tommaso Ferrero SWD

## Test of the exercise

Contains  
● Create a function called aContainsb  
● It should take in two strings, and return true if the first string contains the second, otherwise it should return false  

## Description of the solution of the exercise

This exercise have a function that takes two strings and return true if the first string contain the second one, otherwise it return fals.  
