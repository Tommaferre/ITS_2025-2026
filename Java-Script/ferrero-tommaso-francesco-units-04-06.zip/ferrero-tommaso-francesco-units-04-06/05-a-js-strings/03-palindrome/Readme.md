# Palindrome

## Author

Tommaso Ferrero SWD

## Request

Palindrome  
● Using your reverse() function from the previous exercise, write a simple function to check if a string is a palindrome  
● A palindrome is a word that reads the same backwards as forwards. For example, the word "madam" is a palindrome  
● Write a JavaScript function called isPalindrome which has one parameter, a string, and which returns true if that string is a palindrome, else false  
● For example, the call isPalindrome("madam") should return true, while isPalindrome("madame") should return false  

## Description of the solution for the exercise

This exercise takes the function in the previous exercise and, with another function, check if the reversed string it's equal to the input string.
If it's equal it means that it's a palindrome word if not it isn't.
