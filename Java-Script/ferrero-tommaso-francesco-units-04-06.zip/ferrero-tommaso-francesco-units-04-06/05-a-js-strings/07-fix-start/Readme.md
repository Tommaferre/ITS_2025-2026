# Fix start

## Author

Tommaso Ferrero SWD

## Test of the exercise

FixStart  
● Create a function called fixStart  
● It should take a single parameter, a string, and return a version where all occurrences of its first character have been replaced with '*', except for the first character itself  
● You can assume that the string is at least one character long  

## Description of the solution of the exercise

This exercise have a fixStart function that takes a string and replaces all occurrences of its first character with *, except for the first character itself. It iterates through the string, checking each character, and performs the replacement where necessary. The modified string is returned with the unchanged first character.
