# GRADE MASTER

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Grade master

● Write a function named assignGrade that:  
○ takes 1 parameter, a number score.  
○ returns a grade for the score, either "A", "B", "C", "D", or "F".  
● Call that function for a few different scores and log the result to make sure it works.  

## Description of the solution of the exercise

In this script the assignGrade function takes one parameter, score.
It uses a series of if and else if statements to determine the grade based on the score.
