# EASY MULTIPLICATION

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Easy multiplication

● Write a for loop that will iterate from 0 to 10.  
● For each iteration of the for loop, it will multiply the number by 9 and log the result (e.g. "2 * 9 = 18").  
● Bonus: Use a nested for loop to show the tables for every multiplier from 1 to 10 (100 results total).  

## Description of the solution of the exercise

This exercise demonstrates how to use for loops in JavaScript (also nested) to print multiplication tables, including the multiplication table of 9 and the full multiplication tables from 1 to 10.
