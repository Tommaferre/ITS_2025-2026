# ODD OR EVEN

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Odd or even

● Write a for loop that will iterate from 0 to 20.  
● For each iteration, it will check if the current number is odd or even, and report that to the screen (e.g. "2 is even").  

## Description of the solution of the exercise

In this script the checkEvenOdd function contains the for loop that iterates from 0 to 20.  
Inside the loop, it checks if the current number is even or odd and logs the result to the console.  
After defining the function, we call checkEvenOdd() to execute it.
