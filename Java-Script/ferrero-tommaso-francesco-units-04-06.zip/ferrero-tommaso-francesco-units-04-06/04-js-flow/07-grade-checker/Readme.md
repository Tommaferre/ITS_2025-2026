# GRADE CHECKER

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Grade checker

● Write a loop that tests the function that you wrote earlier “assignGrade”.
● Check every value from 60 to 100:  
○ your log should show  
■ “For 88, you got a B.”  
■ “For 89, you got a B.”  
■ “For 90, you got an A.”  
■ etc.  

## Description of the solution of the exercise

this exercise takes the same function of grade-master exercise and add a  for loop to check every value from 60 to 100.
