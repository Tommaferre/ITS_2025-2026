# UNIVERSAL TRASLATOR

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Universal Translator

● Write a function named helloWorld that:  
○ takes 1 parameter, a language code (e.g. "es", "de", "en")  
○ returns "Hello, World" for the given language, for at least 3 languages. It should default to returning English.  
● Call that function for each of the supported languages and log the result to make sure it works.

## Description of the solution of the exercise

This script return "Hello, World" in the appropriate language based on the language code.
