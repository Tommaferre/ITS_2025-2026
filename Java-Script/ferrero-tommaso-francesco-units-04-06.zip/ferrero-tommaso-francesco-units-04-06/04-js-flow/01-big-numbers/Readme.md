# BIG NUMBERS

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Big numbers

● Write a function named greaterNum that:
○ takes 2 parameters, both numbers.
○ returns whichever number is the greater (higher) number.
● Call that function 2 times with different number pairs, and log the output to make sure it works (e.g. "The greater number of 5 and 10 is 10.").

## Description of the solution of the exercise

This script have a function that with an if-else statement find the greatest number beetwen two numbers.
