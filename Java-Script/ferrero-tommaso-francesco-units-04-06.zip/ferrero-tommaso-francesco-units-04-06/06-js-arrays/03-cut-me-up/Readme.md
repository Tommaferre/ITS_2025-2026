# CUT ME UP

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Cut me up

● In the exercise folder create a .txt or .doc or .md file in which you explain the difference between the following array methods:  
○ slice(), splice()  
○ Explain the differences in terms of parameters and behavior  
○ Provide code examples to prove your point  

## Description of the solution of the exercise

I've created a .md file to describe the difference beetween the two array methods slice() and splice().  
I've provided also code examples to help understand better the differences.
