# Top Choice

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Top choice
  
Create an array to hold your top choices (colors, pets, books, whatever).  
For each choice, log to the screen a string like: "My #1 choice is blue."  

## Description of the solution of the exercise

This script creates an array to hold your top choices (such as colors, pets, books, etc.) and logs each choice to the screen with its corresponding number in the format: "My #1 choice is blue.".  
You can customize your top choices array with your own preferences in the initialization of the array before running the script.
In the bonus part, the script use the getNumberSuffix function to determinate the correct suffix for each number. The for loop then logs on the console each choice with its corresponding number and suffix.
