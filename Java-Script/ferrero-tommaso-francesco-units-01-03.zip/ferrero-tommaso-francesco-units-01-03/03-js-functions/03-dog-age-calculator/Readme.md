this file calculate Function to calculate dog's age in dog years based on the conversion humanAge-conversionRate
by passing different humanAge and different conversionRate the output changes