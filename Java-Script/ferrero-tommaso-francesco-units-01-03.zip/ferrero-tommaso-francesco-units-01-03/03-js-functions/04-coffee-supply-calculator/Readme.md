this is a coffee supply calculator whit a function to calculate the supply of coffee needed for the rest of life
the function in particular calculate the number of days left to live, calculate the total amount consumed in the remaining days, round the result to the nearest whole number,
output the result in both cups and liters.