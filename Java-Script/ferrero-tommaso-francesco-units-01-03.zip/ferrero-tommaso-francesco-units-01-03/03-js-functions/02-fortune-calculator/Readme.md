fortune calculator use a function to calculate your future passing 4 parameters (children, partnerName, location, jobTitle)
Calling the function 3 times with different values for the arguments it prints different future based on the updated parameters
