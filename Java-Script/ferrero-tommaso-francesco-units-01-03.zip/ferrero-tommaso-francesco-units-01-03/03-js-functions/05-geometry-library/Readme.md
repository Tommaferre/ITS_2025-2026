this is a script to calculate the circumference of a circle and to calculate the area of a circle
calling the function with different radius values passed on the call by parameter