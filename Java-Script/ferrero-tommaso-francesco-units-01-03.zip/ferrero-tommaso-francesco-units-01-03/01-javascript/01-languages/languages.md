Answers to the question in the slides


I know python, java, javascript, c and r

C:	Compiled

C is compiled using a compiler (e.g., GCC, Clang). It convert code into machine code before execution, making it fast.

Java: Compiled + Interpreted	

Java is compiled into bytecode (via javac) and then interpreted/executed by the JVM (Java Virtual Machine).

Python: Interpreted	

Python is interpreted by the Python interpreter (CPython, PyPy). Code is executed line by line.

JavaScript: Interpreted 

JavaScript is interpreted by the browser or Node.js. 

R:	Interpreted	

R is interpreted and runs in an interactive environment, often used for data analysis and statistics.

C++	Compiled	
Like C, C++ code is compiled into machine code for execution.

Go (Golang)	Compiled	
Go is compiled into a single binary for fast execution.

PHP	Interpreted	
PHP is interpreted on the server side for web development.

Rust	Compiled	
Rust compiles into highly optimized machine code.


