This is the first progect whit the connection to a js file
it output on the console my name