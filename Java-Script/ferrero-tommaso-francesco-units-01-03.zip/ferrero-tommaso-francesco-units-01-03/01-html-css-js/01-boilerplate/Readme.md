This project contains a basic HTML boilerplate.

### index.html

The `index.html` file is the main entry point of the project. It includes the basic structure of an HTML document, including the `<!DOCTYPE html>`, `<html>`, `<head>`, and `<body>` tags. This file serves as the foundation for building a web page.

## How to Use

1. Open the `index.html` file in your preferred web browser to view the basic HTML structure.
2. Modify the content within the `<body>` tag to start building your web page.
