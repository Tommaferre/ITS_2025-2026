### Temperature converter
is a simple progect to convert Celsius to Fahrenheit and vice versa. It calculates the converted temperature and logs the output to the console.
