// Store the information in variables
let numberOfChildren = 2;
let partnersName = "Giulia";
let geographicLocation = "Turin";
let jobTitle = "Software Developer";

// Output the fortune to the console
console.log(`You will be a ${jobTitle} in ${geographicLocation}, and married to ${partnersName} with ${numberOfChildren} kids.`);