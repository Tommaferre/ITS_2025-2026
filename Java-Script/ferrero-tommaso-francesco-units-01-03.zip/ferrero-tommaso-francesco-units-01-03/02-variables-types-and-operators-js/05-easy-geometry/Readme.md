### Easy geometry
This code calculates the circumference and area of a circle using a given radius. It then logs both values to the console, formatted to two decimal places.