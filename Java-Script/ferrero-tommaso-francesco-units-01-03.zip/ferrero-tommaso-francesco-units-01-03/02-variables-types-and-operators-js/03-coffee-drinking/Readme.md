
### index.html

The `index.html` file serves as the main entry point for the coffee drinking application. It includes the structure of the webpage and links to the `main.js` file. 

### main.js

The `main.js` file calculates the total amount of coffee you will need to drink for the rest of your life based on your current age, estimated maximum age, and daily coffee consumption. It then outputs this information to the console.

