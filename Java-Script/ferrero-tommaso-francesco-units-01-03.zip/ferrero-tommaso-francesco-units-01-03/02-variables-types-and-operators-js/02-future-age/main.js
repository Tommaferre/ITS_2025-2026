// Store birth year and future year in variables
let birthYear = 2003;  // Change this to your birth year
let futureYear = 2030; // Change this to any future year

// Calculate possible ages
let age1 = futureYear - birthYear;
let age2 = age1 - 1;

// Output the result to the console
console.log(`I will be either ${age2} or ${age1} in ${futureYear}.`);