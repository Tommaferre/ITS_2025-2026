
### `index.html`
This file contains the HTML structure for the Future Age Calculator application.

### `main.js`
This file contains the main JavaScript code for calculating the future age based on the user's input. It prompts the user for their current age and the number of years into the future they want to calculate. The script then computes and displays the future age.