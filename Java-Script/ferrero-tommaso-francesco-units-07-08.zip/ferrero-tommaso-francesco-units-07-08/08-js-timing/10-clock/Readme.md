# CLOCK

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Clock

● Implement a javascript clock that prints the current time to the console every second  
● The output should be in the format HH:mm:ss e.g. 17:03:06  

## Description of the solution of the exercise

This project implements a simple JavaScript clock that prints the current time to the console every second.  
The clock uses the setInterval function to do this.  

The time is displayed in the format:  
HH:mm:ss (for example, 19:40:06).  
