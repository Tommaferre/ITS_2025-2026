# READING LIST

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Reading list

● Create an array of objects, where each object describes a book and has properties for the title (a string), author (a string), and alreadyRead (a boolean indicating if you read it yet).  
● Iterate through the array of books. For each book, log the book title and book author like so: "The Hobbit by J.R.R. Tolkien".  
● Now use an if/else statement to change the output depending on whether you read it yet or not. If you read it, log a string like 'You already read "The Hobbit" by J.R.R. Tolkien', and if not, log a string like 'You still need to read "The Lord of the Rings" by J.R.R. Tolkien.'

## Description of the solution of the exercise

In this exercise i've created an array of book objects, every objects have a title, an author and a boolean that indicates if i already read it or not. After i've created a for loop to iterate through the array of the books to log the book title and the book author, then with an if/else statement it log on the output also if i read the book or not.
