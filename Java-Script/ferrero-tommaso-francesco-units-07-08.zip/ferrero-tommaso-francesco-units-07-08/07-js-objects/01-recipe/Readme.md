# RECIPE

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Recipe

● Create an object to hold information on your favorite recipe. It should have properties for title (a string), servings (a number), and ingredients (an array of strings).
● On separate lines (one console.log statement for each), log the recipe information

## Description of the solution of the exercise

In this exercise i've created an object to store the information about my favourite recipe: the pizza "Margherita". It hold the title, te servings and the ingredient of the recipe. After that, on separated lines, the code log the recipe information about the recipe.
