# MOVIE DATABASE

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Movie database

● Create an object to store the following information about a movie: title (a string), duration (a number), and stars (an array of strings).  
● Create an Array of objects that can hold several movies.  
● Create a function to print out the movie information like so: "Puff the Magic Dragon lasts for 30 minutes. Stars: Puff, Jackie, Living Sneezes."  
● Test the function by printing one movie.  
● Use the function to print all the movies in the Array.  

## Description of the solution of the exercise

In this exercise i've created an object to store information about movies: title, duration and the stars acting in it. After i've crated an array of objects that holds several movies, specifically in this case two movies. Then we find a function to print out the movie information, that it's called for the first time to print one movie, and after called for every movie in the array thanks to a for loop.
