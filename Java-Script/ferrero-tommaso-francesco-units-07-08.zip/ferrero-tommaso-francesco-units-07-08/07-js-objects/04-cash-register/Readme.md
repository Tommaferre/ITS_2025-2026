# CASH REGISTER

## Author

Tommaso Ferrero SWD

## Test of the exercise

### Cash register

● Write a function called cashRegister that takes a shopping cart object.  
● The object contains item names and prices (itemName: itemPrice).  
● The function returns the total price of the shopping cart, e.g. :

```javascript
// Input
let cartForParty = {
 banana: "1.25",
 handkerchief: ".99",
 Tshirt: "25.01",
 apple: "0.60",
 nalgene: "10.34",
 proteinShake: "22.36"
};
// Output
cashRegister(cartForParty); // 60.55
```

## Description of the solution of the exercise

In this exercise i've writed a function called cashRegister that takes a shopping cart object. In the object there are stored items names and their prices. The function returns the total price of the shopping cart.
